package com.example.ad_practicaregistro

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import com.bumptech.glide.Glide
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.Serializable

class Infouser : AppCompatActivity() {
    lateinit var imagen: ImageView
    lateinit var nombre: TextView
    lateinit var horasVuelo: TextView
    lateinit var contraseña: TextView
    lateinit var fecha: TextView
    lateinit var btn_modificar: Button
    lateinit var btn_baja:Button
    lateinit var chatPrivado:Button
    lateinit var chatPublico:Button

    lateinit var SP: SharedPreferences

    private lateinit var db_ref: DatabaseReference
    private lateinit var sto_ref: StorageReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_infouser)
    }

    override fun onStart() {
        super.onStart()
        var pojo_usuario=intent.getSerializableExtra("usuario") as Usuario

        val app_id = "com.example.ad_practicaregistro"
        val sp_name = "${app_id}_practica"
        SP = getSharedPreferences(sp_name, 0)

        var loged = SP.getString(R.string.sp_nombre_usuario.toString(),"1")
        var tipo_user = SP.getString("tipo","normal")

        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()

        /*
        if(loged==""){

            val intent = Intent(applicationContext,MainActivity::class.java)
            this.startActivity(intent)
        }*/

        imagen = findViewById(R.id.infouser_imagen)
        nombre = findViewById(R.id.infouser_nombre)
        horasVuelo = findViewById(R.id.infouser_horasVuelo)
        contraseña = findViewById(R.id.infouser_contraseña)
        fecha=findViewById(R.id.infouser_fecha)
        btn_modificar = findViewById(R.id.infouser_editar)
        btn_baja = findViewById(R.id.infouser_baja)
        chatPublico = findViewById(R.id.button5)
        chatPrivado = findViewById(R.id.button6)


        Glide.with(applicationContext).load(pojo_usuario.url_imagen).into(imagen)
        nombre.setText(pojo_usuario.nombre)
        horasVuelo.setText(pojo_usuario.horasVuelo.toString())
        contraseña.setText(pojo_usuario.contraseña)
        fecha.setText(pojo_usuario.fecha)

        btn_modificar.setOnClickListener{
            val intent = Intent(this,ModificarUsuario::class.java)
            intent.putExtra("usuario", pojo_usuario as Serializable)
            startActivity(intent)
        }
        btn_baja.setOnClickListener{

            sto_ref.child("hangar").child("fotos").child(pojo_usuario.id!!).delete()
            db_ref.child("hangar").child("pilotos").child(pojo_usuario.id!!).removeValue()

            Toast.makeText(applicationContext, "Ha cerrado sesion", Toast.LENGTH_SHORT).show()
            with(SP.edit()){
                putString(R.string.sp_nombre_usuario.toString(), "")
                putString(R.string.sp_tipo_usuario.toString(),"")

                commit()
            }

            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)

        }

        chatPrivado.setOnClickListener{
            Toast.makeText(applicationContext, "Espacio nes desarrollo", Toast.LENGTH_SHORT).show()
        }
        chatPublico.setOnClickListener{
            Toast.makeText(applicationContext, "Espacio nes desarrollo", Toast.LENGTH_SHORT).show()
        }

    }
}