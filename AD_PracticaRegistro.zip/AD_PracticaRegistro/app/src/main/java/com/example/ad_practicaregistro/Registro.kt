package com.example.ad_practicaregistro

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.CountDownLatch

class Registro : AppCompatActivity() {
    lateinit var avatar:ImageView
    lateinit var username:EditText
    lateinit var password1:EditText
    lateinit var password2:EditText
    lateinit var horasVuelo:EditText
    lateinit var registrar:Button

    private var url_avatar: Uri?=null

    private lateinit var db_ref: DatabaseReference
    private lateinit var sto_ref: StorageReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)
    }

    override fun onStart() {
        super.onStart()
        avatar = findViewById(R.id.registro_iv_imagen)
        username = findViewById(R.id.registro_et_username)
        password1 = findViewById(R.id.registro_et_password)
        password2 = findViewById(R.id.registro_et_passwordAgain)
        horasVuelo = findViewById(R.id.registro_et_horasVuelo)
        registrar = findViewById(R.id.registro_btn_signUp)

        val sdf = SimpleDateFormat("YYYY-MM-DD")
        val currentDate = sdf.format(Date())

        db_ref = FirebaseDatabase.getInstance().getReference()
        sto_ref = FirebaseStorage.getInstance().getReference()


        registrar.setOnClickListener{
            var id_generado:String?=null

            if(username.text.toString().trim().equals("") ||
                password1.text.toString().trim().equals("") ||
                password2.text.toString().trim().equals("") ||
                horasVuelo.text.toString().trim().equals("")) {

                Toast.makeText(applicationContext, "Faltan datos", Toast.LENGTH_SHORT)
                    .show()
            }else if (password1.text.toString().trim() != password2.text.toString().trim()) {
                Toast.makeText(applicationContext, "La contraseña no coincide en los dos campos", Toast.LENGTH_SHORT).show()

            }else if (horasVuelo.text.toString().trim().toIntOrNull()==null ||
                        horasVuelo.text.toString().trim().toInt()<=0){
                Toast.makeText(applicationContext, "Las horas de vuelo tienen que ser un número y mayor que 0", Toast.LENGTH_SHORT).show()
            }else if (url_avatar==null){
                Toast.makeText(applicationContext, "Falta seleccionar una foto de avatar", Toast.LENGTH_SHORT).show()
            }else{
                registrar.isEnabled=false
                GlobalScope.launch(Dispatchers.IO) {
                    if (usuarioExiste(username.text.toString().trim())) {
                        tostadaCorrutina("El usuario ya existe en la base de datos")
                    } else {
                        id_generado=db_ref.child("hangar").child("pilotos").push().key

                        val url_usuario_firebase=insertarImagen(id_generado!!,url_avatar!!)

                        insertarUsuario(id_generado!!,
                            username.text.toString().trim(),
                            password1.text.toString().trim(),
                            "normal",
                            url_usuario_firebase,
                            currentDate,
                            horasVuelo.text.toString().trim().toInt(),
                            0
                        )

                        tostadaCorrutina("USuario insertado en la base de datos")
                        val actividad = Intent(applicationContext, MainActivity::class.java)
                        startActivity(actividad)
                    }
                }
            }

        }

        avatar.setOnClickListener{
            obtener_url.launch("image/*")
        }

       avatar.setOnLongClickListener{
            val ficheroFoto=crearFicheroImagen()
            url_avatar= FileProvider.getUriForFile(applicationContext,"com.example.ad_practicaregistro.fileprovider",ficheroFoto)
            getCamera.launch(url_avatar)

            return@setOnLongClickListener true
        }
    }

    private suspend fun usuarioExiste(nombre:String):Boolean{
        var resultado:Boolean?=false

        val semaforo= CountDownLatch(1)

        db_ref.child("hangar")
            .child("pilotos")
            .orderByChild("nombre")
            .equalTo(nombre)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if(snapshot.getValue(Usuario::class.java)!=null){
                        resultado=true;
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })

        semaforo.await();

        return resultado!!;
    }

    val getCamera=registerForActivityResult(ActivityResultContracts.TakePicture()){
        if(it){
            avatar.setImageURI(url_avatar)

            Toast.makeText(applicationContext, "He hechado una foto", Toast.LENGTH_SHORT).show()
        }else{
            Toast.makeText(applicationContext, "No se ha hechado una foto", Toast.LENGTH_SHORT).show()
        }
    }

    private fun crearFicheroImagen(): File {
        val cal: Calendar?= Calendar.getInstance()
        val timeStamp:String?= SimpleDateFormat("yyyyMMdd_HHmmss").format(cal!!.time)
        val nombreFichero:String?="JPGE_"+timeStamp+"_"
        val carpetaDir: File?=applicationContext.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        val ficheroImagen: File?= File.createTempFile(nombreFichero!!,".jpg",carpetaDir)

        return ficheroImagen!!
    }

    private suspend fun insertarImagen(id:String,imagen:Uri):String{
        lateinit var url_usuario_firebase:Uri

        url_usuario_firebase=sto_ref.child("hangar").child("fotos").child(id)
            .putFile(imagen).await().storage.downloadUrl.await()

        return url_usuario_firebase.toString()
    }

    private suspend fun insertarUsuario(id:String,nombre:String,contraseña:String,tipo:String,
                                      url_imagen:String,fecha:String,horasVuelo:Int,estado:Int) {
        val nuevo_avion = Usuario(
            id,
            nombre,
            contraseña,
            tipo,
            url_imagen,
            fecha,
            horasVuelo,
            estado
        )
        db_ref.child("hangar").child("pilotos").child(id).setValue(nuevo_avion)
    }



    private val obtener_url= registerForActivityResult(ActivityResultContracts.GetContent()){
            uri:Uri?->
        when (uri){
            null-> Toast.makeText(applicationContext,"No has seleccionado una imagen", Toast.LENGTH_SHORT).show()
            else->{
                url_avatar=uri
                avatar.setImageURI(url_avatar)
                Toast.makeText(applicationContext,"Has seleccionado una imagen", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun tostadaCorrutina(texto:String){
        runOnUiThread{
            Toast.makeText(
                applicationContext,
                texto,
                Toast.LENGTH_SHORT
            ).show()
        }
    }

}