package com.example.ad_practicaregistro

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.Serializable

class VerUsuarios : AppCompatActivity() {
    lateinit var rv:RecyclerView

    lateinit var SP: SharedPreferences
    lateinit var nombre:TextView
    lateinit var propiaCuenta:Button
    lateinit var chatPrivado:Button
    lateinit var chatPublico:Button

    private lateinit var db_ref: DatabaseReference
    private lateinit var sto_ref: StorageReference

    private lateinit var pojo_usuario:Usuario


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ver_usuarios)
    }

    override fun onStart() {
        super.onStart()





        pojo_usuario=intent.getSerializableExtra("usuario") as Usuario
        var propioId=pojo_usuario.id

        val app_id = "com.example.ad_practicaregistro"
        val sp_name = "${app_id}_practica"
        SP = getSharedPreferences(sp_name, 0)

        var loged = SP.getString(
            R.string.sp_nombre_usuario.toString(),
            R.string.sp_nombre_usuario_def.toString()
        )

        var tipo = SP.getString(
            R.string.sp_tipo_usuario.toString(),
            R.string.sp_tipo_usuario_def.toString()
        )
/*
        if(loged=="" || tipo=="" || tipo =="normal" ){
            val intent = Intent(applicationContext,MainActivity::class.java)
            this.startActivity(intent)
        }*/
        nombre =findViewById(R.id.ver_usuario_nombre)
        nombre.setText(pojo_usuario.nombre)

        propiaCuenta = findViewById(R.id.ver_usuarios_propiaCuenta)
        propiaCuenta.setOnClickListener{
            val intent = Intent(applicationContext,Modificar_admin::class.java)
            intent.putExtra("usuario", pojo_usuario as Serializable)
            this.startActivity(intent)
        }

        chatPrivado = findViewById(R.id.ver_usuariochatPrivado)
        chatPrivado.setOnClickListener{
            Toast.makeText(applicationContext,"El chat privado estara disponible pronto", Toast.LENGTH_SHORT).show()
        }
        chatPublico = findViewById(R.id.ver_usuario_chatPublico)
        chatPublico.setOnClickListener{
            Toast.makeText(applicationContext,"El chat publico estara disponible pronto", Toast.LENGTH_SHORT).show()
        }
        var lista = mutableListOf<Usuario>()

        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()

        db_ref.child("hangar")
            .child("pilotos")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    lista.clear()
                    snapshot.children.forEach{ hijo: DataSnapshot?->
                        val pojo_usuario=hijo?.getValue(Usuario::class.java)
                        if(pojo_usuario?.id!=propioId){
                            lista.add(pojo_usuario!!)
                        }
                    }
                    rv.adapter?.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })

        rv = findViewById(R.id.ver_usuarios_rv)
        rv.adapter=AdaptadorUsuarios(lista)
        rv.layoutManager= LinearLayoutManager(applicationContext)
        rv.setHasFixedSize(true)
    }
}