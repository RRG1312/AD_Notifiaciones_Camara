package com.example.ad_practicaregistro

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.Serializable
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : AppCompatActivity() {
    private lateinit var contexto: Context

    lateinit var SP: SharedPreferences

    lateinit var username:EditText
    lateinit var password:EditText
    lateinit var login:Button
    lateinit var createAccount:TextView
    var pojo_usuario:Usuario?= Usuario()

    private lateinit var generador: AtomicInteger

    private lateinit var db_ref: DatabaseReference
    private lateinit var sto_ref: StorageReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onStart() {
        super.onStart()
        username=findViewById(R.id.main_et_username) as EditText
        password=findViewById(R.id.main_et_password)
        login=findViewById(R.id.main_btn_login)
        createAccount=findViewById(R.id.main_tv_createAccount)

        generador=AtomicInteger(0)

        val app_id = R.string.app_name
        val sp_name = "${app_id}_practica"
        SP = getSharedPreferences(sp_name, 0)

        var loged = SP.getString(R.string.sp_nombre_usuario.toString(),R.string.sp_nombre_usuario_def.toString())
        var tipo_user =SP.getString(R.string.sp_tipo_usuario.toString(),R.string.sp_tipo_usuario_def.toString())


        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()

        if(loged!="" ){
            username.setText(loged)?:"0"
        }else if(tipo_user=="admin"){

            //startActivity(Intent(applicationContext,VerUsuarios::class.java))
        }

        createAccount.setOnClickListener{
            val intent = Intent(this,Registro::class.java)
            startActivity(intent)
        }

        login.setOnClickListener {
            if (username.text.toString().trim() == "") {
                username.error = "Introduce un usuario"
            } else if (password.text.toString().trim() == "") {
                password.error = "Introduce la contraseña"
            } else {
                db_ref.child("hangar").child("pilotos")
                    .orderByChild("nombre").equalTo(username.text.toString().trim())
                    .addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            if (snapshot.hasChildren()) {
                                pojo_usuario = snapshot.children.iterator().next()
                                    .getValue(Usuario::class.java)
                                if (pojo_usuario?.contraseña.equals(
                                        password.text.toString().trim()
                                    )
                                ) {
                                    val intent:Intent
                                    if (pojo_usuario?.tipo == "normal") {
                                        intent = Intent(applicationContext, Infouser::class.java)
                                        intent.putExtra("usuario", pojo_usuario as Serializable)
                                    } else {
                                        intent = Intent(applicationContext, VerUsuarios::class.java)
                                        intent.putExtra("usuario", pojo_usuario as Serializable)
                                    }
                                    with(SP.edit()){
                                        putString(R.string.sp_nombre_usuario.toString(), pojo_usuario?.nombre.toString())
                                        putString(R.string.sp_tipo_usuario.toString(),pojo_usuario?.tipo.toString())

                                        commit()
                                    }
                                    startActivity(intent)
                                } else {
                                    Toast.makeText(
                                        applicationContext,
                                        "Contraseña incorrecta",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } else {
                                Toast.makeText(
                                    applicationContext,
                                    "No existe el usuario",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }

                        override fun onCancelled(error: DatabaseError) {
                            Toast.makeText(
                                applicationContext,
                                "Error en el login",
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                    })
            }
        }
        db_ref.child("hangar").child("pilotos")
            .addChildEventListener(object : ChildEventListener {
                override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {

                    var pojo_usuario_noti=snapshot.getValue(Usuario::class.java)
                    if(!pojo_usuario!!.id.equals(pojo_usuario_noti?.id) && pojo_usuario!!.estado_noti==Estado.CREADO){
                        db_ref.child("hangar").child("pilotos").child(pojo_usuario!!.id!!).child("estado_noti").setValue(Estado.NOTIFICADO)
                        generarNotificacion(generador.incrementAndGet(),pojo_usuario!!,"Se ha creado el club "+pojo_usuario!!.nombre,"Nuevos datos en la app",ModificarUsuario::class.java)
                    }

                }

                override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                    var pojo_usuario_noti=snapshot.getValue(Usuario::class.java)
                    if(!pojo_usuario!!.id.equals(pojo_usuario_noti?.id) && pojo_usuario!!.estado_noti==Estado.MODIFICADO) {
                        generarNotificacion(
                            generador.incrementAndGet(),
                            pojo_usuario!!,
                            "Se ha modificado el usuario " + pojo_usuario!!.nombre,
                            "Datos editados en la app",
                            ModificarUsuario::class.java
                        )
                        db_ref.child("hangar").child("pilotos").child(pojo_usuario!!.id!!).child("estado_noti")
                            .setValue(Estado.NOTIFICADO)
                    }else if(!pojo_usuario!!.id.equals(pojo_usuario_noti?.id) && pojo_usuario!!.estado_noti==Estado.MODIFICADO_NOMBRE){
                        generarNotificacion(generador.incrementAndGet(),pojo_usuario!!,"Ahora se llama "+pojo_usuario!!.nombre,"Actualizacion de club en la app",ModificarUsuario::class.java)
                        db_ref.child("hangar").child("pilotos").child(pojo_usuario!!.id!!).child("estado_noti")
                            .setValue(Estado.NOTIFICADO)
                    }


                }

                override fun onChildRemoved(snapshot: DataSnapshot) {
                    val pojo_usuario_noti=snapshot.getValue(Usuario::class.java)
                    if(!pojo_usuario!!.id.equals(pojo_usuario_noti?.id)){
                        generarNotificacion(generador.incrementAndGet(),pojo_usuario!!,"Se ha borrado el usuario "+pojo_usuario!!.nombre,"Datos borrados en la app",VerUsuarios::class.java)
                    }
                }

                override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {

                }

                override fun onCancelled(error: DatabaseError) {

                }
            })
    }

    private fun generarNotificacion(id_noti:Int,pojo:Serializable,contenido:String,titulo:String,destino:Class<*>) {
        val idcanal = getString(R.string.id_canal)
        val iconolargo = BitmapFactory.decodeResource(
            resources,
            R.drawable.icons8_enviado_24
        )
        val actividad = Intent(applicationContext,destino)
        actividad.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK )
        actividad.putExtra("club", pojo)
        val pendingIntent= PendingIntent.getActivity(this,0,actividad, PendingIntent.FLAG_UPDATE_CURRENT)

        val notification = NotificationCompat.Builder(this, idcanal)
            .setLargeIcon(iconolargo)
            .setSmallIcon(R.drawable.icons8_enviado_24)
            .setContentTitle(titulo)
            .setContentText(contenido)
            .setSubText("sistema de información")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        with(NotificationManagerCompat.from(this)){
            notify(id_noti,notification)
        }
    }

    private fun crearCanalNotificaciones() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nombre = getString(R.string.nombre_canal)
            val idcanal = getString(R.string.id_canal)
            val descripcion = getString(R.string.description_canal)
            val importancia = NotificationManager.IMPORTANCE_DEFAULT

            val channel = NotificationChannel(idcanal, nombre, importancia).apply {
                description = descripcion
            }

            val nm: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }
}